/**
 * \file
 *
 * \brief Empty user application template
 *
 */

/**
 * \mainpage User Application template doxygen documentation
 *
 * \par Empty user application template
 *
 * Bare minimum empty user application template
 *
 * \par Content
 *
 * -# Include the ASF header files (through asf.h)
 * -# "Insert system clock initialization code here" comment
 * -# Minimal main function that starts with a call to board_init()
 * -# "Insert application code here" comment
 *
 */

/*
 * Include header files for all drivers that have been imported from
 * Atmel Software Framework (ASF).
 */
/*
 * Support and FAQ: visit <a href="https://www.microchip.com/support/">Microchip Support</a>
 */
#include <asf.h>
#include "pio.h"
sam_uart_opt_t uart_config;

uint8_t text_vsl=0;
char uart_rcv=0;

void UART_Handler(void){
	
	uart_read(UART,&uart_rcv);
		if (uart_rcv=='A')
		{
			text_vsl=1;
		}
		else if (uart_rcv=='X')
		{
			text_vsl=0;
		}
}

void Uart_setup(void)
{
	uart_config.ul_baudrate = 9600;
	uart_config.ul_mck = 84000000;
	uart_init(UART,&uart_config);
	uart_enable_interrupt(UART,(1<<0));
	NVIC_SetPriority(UART_IRQn,6);
	NVIC_EnableIRQ(UART_IRQn);
	uart_enable_rx(UART);
	uart_enable_tx(UART);

}
int main (void)
{
	/* Insert system clock initialization code here (sysclk_init()). */
	sysclk_init();
	pmc_enable_periph_clk(ID_PIOA);
	pio_set_peripheral(PIOA,PIO_PERIPH_A,(1<<8)|(1<<9));
	
	pmc_enable_periph_clk(ID_UART);
	board_init();
	Uart_setup();
	
	while (true){
		if(!text_vsl){uart_write(UART,'X');}
		else{		  uart_write(UART,'A');}
		
		delay_ms(100);
		uart_write(UART,'\n');
		delay_ms(100);
		

	}

	/* Insert application code here, after the board has been initialized. */
}
